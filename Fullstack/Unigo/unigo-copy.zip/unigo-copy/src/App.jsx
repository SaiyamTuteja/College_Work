import React from "react";
import { BrowserRouter as Router, Routes, Route } from "react-router-dom";

import Searchdestination from "./components/Searchdestination";
import FindVehical from "./components/FindVehical/Findvehical";
import Filter from "./components/FindVehical/Filter";
import VehicleDetail from "./components/FindVehical/VehicleDetail";
import UserProfile from "./components/UserProfile/UserProfile";
import ChatMessage from "./components/ChatMessage/ChatMessage";

function App() {
  return (
    <Router>
      <Routes>
        <Route path="/" element={<Searchdestination />} />
        <Route path="/find-vehicle" element={<FindVehical />} />
        <Route path="/filter" element={<Filter />} />
        <Route path="/vehicle-detail" element={<VehicleDetail />} />
        <Route path="/user-profile" element={<UserProfile />} />
        <Route path="/chat" element={<ChatMessage />} />
      </Routes>
    </Router>
  );
}

export default App;
